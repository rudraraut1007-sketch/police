// Vercel serverless entry: exposes the Express app for every /api/* request.
module.exports = require('../server/index.js');
