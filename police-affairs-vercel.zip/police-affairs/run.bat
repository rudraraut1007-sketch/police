@echo off
setlocal enabledelayedexpansion
title Police Affairs DBMS Portal

echo ========================================================
echo   POLICE AFFAIRS & INTERNAL AFFAIRS DBMS PORTAL
echo ========================================================
echo.

:: 1. Detect Node.js in PATH or standard installation directories
where node >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    if exist "C:\Program Files\nodejs\node.exe" (
        set "PATH=C:\Program Files\nodejs;%APPDATA%\npm;!PATH!"
        echo [*] Node.js located at C:\Program Files\nodejs
    ) else if exist "%LOCALAPPDATA%\Programs\nodejs\node.exe" (
        set "PATH=%LOCALAPPDATA%\Programs\nodejs;%APPDATA%\npm;!PATH!"
        echo [*] Node.js located at %LOCALAPPDATA%\Programs\nodejs
    ) else (
        echo [ERROR] Node.js was not found on your system!
        echo Please ensure Node.js is installed from https://nodejs.org
        pause
        exit /b 1
    )
)

echo [*] Using Node.js:
node -v
echo [*] Using NPM:
call npm -v
echo.

cd /d "%~dp0"

:: 2. Install dependencies (single package.json at project root)
if not exist "node_modules" (
    echo [*] Installing dependencies...
    call npm install
)

:: 3. Start Backend Server
echo [*] Launching Police Affairs API Server (Port 5000)...
start "Police Affairs API Server" cmd /k "cd /d "%~dp0" && npm run server"

:: 4. Wait for server to initialize
timeout /t 3 /nobreak >nul

:: 5. Start Frontend Web UI
echo [*] Launching Web UI (Port 5173)...
start "Police Affairs Web UI" cmd /k "cd /d "%~dp0" && npm run dev"

:: 7. Wait and launch browser
timeout /t 3 /nobreak >nul
echo.
echo ========================================================
echo  System is running!
echo  Backend API: http://localhost:5000
echo  Web Portal:  http://localhost:5173
echo ========================================================
echo.
echo Opening browser...
start http://localhost:5173

pause

